var Employee={
name :"Prasad",
id:1,
sal:10000
};
console.log(JSON.stringify.Employee);